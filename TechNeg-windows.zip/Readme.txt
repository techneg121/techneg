-------Welcome-----------
1. Right click on install.ps1 and run with powershell.
2. Wait for the powershell to run.
3. Powershell will open, if prompted write Y/A to install the app.
